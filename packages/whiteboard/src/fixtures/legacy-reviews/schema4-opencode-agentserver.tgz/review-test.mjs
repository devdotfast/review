import { spawn } from "node:child_process";

const rawCommand = process.env.DEV_FAST_REVIEW_INTERNAL_COMMAND;
if (!rawCommand) {
  console.error("DEV_FAST_REVIEW_INTERNAL_COMMAND is required.");
  process.exitCode = 1;
} else {
  const command = JSON.parse(rawCommand);
  const child = spawn(command[0], [...command.slice(1), "internal-test", ...process.argv.slice(2)], {
    stdio: "inherit",
  });
  child.once("error", (error) => { console.error(error); process.exitCode = 1; });
  child.once("exit", (code, signal) => {
    process.exitCode = code ?? (signal ? 1 : 0);
  });
}
