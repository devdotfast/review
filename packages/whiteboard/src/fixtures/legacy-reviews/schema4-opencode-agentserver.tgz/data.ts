import {
  defineActors,
  defineAnchors,
} from "virtual:progressive-review-authoring";

export const actors = defineActors({
  reviewCli: {
    label: "Review CLI/desktop",
    softwareMapPath: "review.cliPackage.authoring",
  },
  opencodeServe: {
    label: "opencode serve",
    softwareMapPath: "review.cliPackage.nativeAgents.opencodeServe",
  },
});

export const anchors = defineAnchors({
  harnessUnion: {
    title: "ReviewAgentHarness",
    peek: {
      file: "packages/progressive-review/src/authoring-session.ts",
      fromLine: 1,
      toLine: 1,
    },
    softwareMapPath: "review.cliPackage.authoring.authoringSession",
  },
  contractsEnum: {
    title: "AuthoringAgentSessionSchema",
    peek: {
      file: "packages/review-protocol/src/contracts.ts",
      fromLine: 1223,
      toLine: 1226,
    },
    softwareMapPath: "review.protocolPackage.contracts",
  },
  opencodeAgentServer: {
    title: "OpencodeAgentServer",
    peek: {
      file: "packages/progressive-review/src/native-agent/opencode.ts",
      fromLine: 50,
      toLine: 66,
    },
    softwareMapPath: "review.cliPackage.nativeAgents.opencodeServer",
  },
  launch: {
    title: "launch()",
    peek: {
      file: "packages/progressive-review/src/native-agent/opencode.ts",
      fromLine: 67,
      toLine: 121,
    },
    softwareMapPath: "review.cliPackage.nativeAgents.opencodeServer",
  },
  clientSession: {
    title: "OpencodeClient.session()",
    peek: {
      file: "packages/progressive-review/src/native-agent/opencode.ts",
      fromLine: 373,
      toLine: 401,
    },
    softwareMapPath: "review.cliPackage.nativeAgents.opencodeServe",
  },
  forkOpencodeSession: {
    title: "forkOpencodeSession",
    peek: {
      file: "packages/progressive-review/src/native-agent/opencode.ts",
      fromLine: 538,
      toLine: 558,
    },
    softwareMapPath: "review.cliPackage.authoring.reviewSourceAgentSession",
  },
  createOpencodeSession: {
    title: "createOpencodeSession",
    peek: {
      file: "packages/progressive-review/src/native-agent/opencode.ts",
      fromLine: 571,
      toLine: 611,
    },
    softwareMapPath: "review.cliPackage.authoring.tutorialAuthoringSession",
  },
  desktopServer: {
    title: "desktop-server harness table",
    peek: {
      file: "packages/progressive-review/src/server/desktop-server.ts",
      fromLine: 283,
      toLine: 284,
    },
    softwareMapPath: "review.cliPackage.serverSurface.desktopServer",
  },
  opencodeTest: {
    title: "opencode.test.ts",
    peek: {
      file: "packages/progressive-review/src/native-agent/opencode.test.ts",
      fromLine: 1,
      toLine: 40,
    },
    detail: "Fake `opencode serve` over a real HTTP server: session create/fork scoped by directory, message projection, and the SSE event stream.",
    softwareMapPath: "review.cliPackage.nativeAgents.opencodeServer",
  },
});

export const forkMessages = [
  {
    from: actors.reviewCli,
    to: actors.opencodeServe,
    label: "GET /project, then GET /session/:id in each worktree until one answers",
    anchor: anchors.clientSession,
  },
  {
    from: actors.reviewCli,
    to: actors.opencodeServe,
    label: "POST /session/:id/fork, scoped to the source session's own directory",
    anchor: anchors.forkOpencodeSession,
  },
  {
    from: actors.reviewCli,
    to: actors.opencodeServe,
    label: "opencode attach <url> --session <id> --dir <source directory>",
    anchor: anchors.launch,
  },
];
