var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// review-document:review:document
var review_document_exports = {};
__export(review_document_exports, {
  default: () => MDXContent
});

// review-document:virtual:progressive-review-authoring
import { calls, createBrowserReviewDefinitionSession, defineSoftwareModel } from "review-doc-runtime";
var session = createBrowserReviewDefinitionSession({
  routePath: "/",
  softwareMap: null,
  baseSoftwareMap: null
});
session.begin();
var defineActors = session.defineActors;
var defineAnchors = session.defineAnchors;
var defineStores = session.defineStores;
var defineSoftwareActors = session.defineSoftwareActors;
var defineSoftwareStores = session.defineSoftwareStores;
var __reviewDefinitionsReady = session.ready;

// review-document:review:document
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "review-doc-runtime";

// authoring-conversation.json
var authoring_conversation_default = {
  version: 1,
  title: "How this Review was made",
  messages: [
    {
      role: "user",
      body: "/dev-review I'd like to review the feature we just worked on."
    },
    {
      role: "assistant",
      body: "Ok, I'm on it..."
    }
  ]
};

// data.ts
var authoringConversation = {
  version: authoring_conversation_default.version,
  title: authoring_conversation_default.title,
  messages: authoring_conversation_default.messages.map((message) => ({
    role: message.role,
    body: message.body
  }))
};
var anchors = defineAnchors({
  checkout: {
    title: "Checkout API calls the order service",
    peek: { file: "src/api/checkout-api.ts", fromLine: 12, toLine: 15 },
    softwareMapPath: "orderService.api.checkout"
  },
  placeOrder: {
    title: "Order service creates the order",
    peek: { file: "src/orders/order-service.ts", fromLine: 13, toLine: 29 },
    softwareMapPath: "orderService.application.orders"
  },
  insertOrder: {
    title: "Repository writes and queues the order",
    peek: { file: "src/orders/orders-repository.ts", fromLine: 9, toLine: 12 },
    softwareMapPath: "orderService.data.ordersRepository"
  },
  validateInventory: {
    title: "Inventory rejects invalid quantities",
    peek: {
      file: "src/inventory/inventory-service.ts",
      fromLine: 4,
      toLine: 8
    },
    softwareMapPath: "orderService.application.orders"
  },
  dequeue: {
    title: "Queue gives work to the fulfillment worker",
    peek: {
      file: "src/fulfillment/fulfillment-worker.ts",
      fromLine: 13,
      toLine: 14
    },
    softwareMapPath: "orderService.fulfillment.worker"
  },
  ship: {
    title: "Worker creates the shipment",
    peek: {
      file: "src/fulfillment/fulfillment-worker.ts",
      fromLine: 17,
      toLine: 19
    },
    softwareMapPath: "orderService.fulfillment.worker"
  },
  ordersTable: {
    title: "Orders table",
    peek: { file: "src/database/schema.ts", fromLine: 1, toLine: 10 },
    softwareMapPath: "orderService.data.ordersDatabase"
  }
});
var actors = defineActors({
  checkout: {
    label: "Checkout API",
    softwareMapPath: "orderService.api.checkout"
  },
  orderService: {
    label: "Order service",
    softwareMapPath: "orderService.application.orders"
  },
  repository: {
    label: "Orders repository",
    softwareMapPath: "orderService.data.ordersRepository"
  },
  queue: {
    label: "Fulfillment queue",
    softwareMapPath: "orderService.fulfillment.queue"
  },
  worker: {
    label: "Fulfillment worker",
    softwareMapPath: "orderService.fulfillment.worker"
  },
  shipping: {
    label: "Shipping gateway",
    softwareMapPath: "orderService.shipping.gateway"
  }
});
var checkoutSequence = [
  {
    from: actors.checkout,
    to: actors.orderService,
    label: "Place order",
    anchor: anchors.checkout
  },
  {
    from: actors.orderService,
    to: actors.repository,
    label: "Save order",
    anchor: anchors.placeOrder
  },
  {
    from: actors.repository,
    to: actors.queue,
    label: "Enqueue fulfillment",
    anchor: anchors.insertOrder
  },
  {
    from: actors.queue,
    to: actors.worker,
    label: "Deliver job",
    anchor: anchors.dequeue
  },
  {
    from: actors.worker,
    to: actors.shipping,
    label: "Create shipment",
    anchor: anchors.ship
  }
];
var stores = defineStores({
  orderDatabase: {
    kind: "relational",
    label: "Order database",
    softwareMapPath: "orderService.data.ordersDatabase",
    tables: {
      orders: {
        label: "orders",
        schema: {
          id: { type: "text", pk: true, example: "order-customer-42" },
          customerId: { type: "text", example: "customer-42" },
          totalCents: { type: "integer", example: 12500 },
          status: { type: "text", example: "fulfilled" },
          createdAt: { type: "timestamp", example: "2026-08-10T12:00:00Z" }
        }
      }
    }
  }
});

// review-document:review:document
function _createMdxContent(props) {
  const _components = {
    h1: "h1",
    h2: "h2",
    h3: "h3",
    p: "p",
    strong: "strong",
    ...props.components
  }, { AnchorLink, CodePeek, DatabaseLens, DbUseCase, DbWrite, ReviewSection, SequenceDiagram, TutorialAuthoringConversation, TutorialFeature, TutorialKeymapPicker, TutorialViewButton } = _components;
  if (!AnchorLink)
    _missingMdxReference("AnchorLink", true);
  if (!CodePeek)
    _missingMdxReference("CodePeek", true);
  if (!DatabaseLens)
    _missingMdxReference("DatabaseLens", true);
  if (!DbUseCase)
    _missingMdxReference("DbUseCase", true);
  if (!DbWrite)
    _missingMdxReference("DbWrite", true);
  if (!ReviewSection)
    _missingMdxReference("ReviewSection", true);
  if (!SequenceDiagram)
    _missingMdxReference("SequenceDiagram", true);
  if (!TutorialAuthoringConversation)
    _missingMdxReference("TutorialAuthoringConversation", true);
  if (!TutorialFeature)
    _missingMdxReference("TutorialFeature", true);
  if (!TutorialKeymapPicker)
    _missingMdxReference("TutorialKeymapPicker", true);
  if (!TutorialViewButton)
    _missingMdxReference("TutorialViewButton", true);
  return _jsxs(_Fragment, { children: [_jsx(_components.h1, { "data-review-block-index": "0", "data-review-block-tag": "h1", children: "Review Desktop: three-minute tour" }), "\n", _jsxs(ReviewSection, { title: "Welcome", children: [_jsx(_components.h2, { "data-review-block-index": "1", "data-review-block-tag": "h2", children: "Welcome" }), _jsx(_components.p, { "data-review-block-index": "2", "data-review-block-tag": "p", children: "A Review is a guided, interactive explanation of a code change. The document\nkeeps the important code, system views, and feedback in one place." }), _jsx(TutorialAuthoringConversation, { conversation: authoringConversation }), _jsx(_components.h3, { "data-review-block-index": "3", "data-review-block-tag": "h3", children: "Your keybindings" }), _jsx(_components.p, { "data-review-block-index": "4", "data-review-block-tag": "p", children: "Choose your editor keys. Review highlights the active choice and uses its\nexisting extension and reload flow for Vim and Emacs." }), _jsx(TutorialKeymapPicker, {}), _jsx(_components.h3, { "data-review-block-index": "5", "data-review-block-tag": "h3", children: "Put the keybindings to work" }), _jsxs(_components.p, { "data-review-block-index": "6", "data-review-block-tag": "p", children: ["The editor below is live. Try hover, ", _jsx(_components.strong, { children: "Go to Definition" }), ", or ", _jsx(_components.strong, { children: "Go to\nReferences" }), " with the same commands you use in VS Code."] }), _jsx(CodePeek, { anchor: anchors.placeOrder }), _jsxs(_components.p, { "data-review-block-index": "7", "data-review-block-tag": "p", children: ["Prose in the review also supports ", _jsx(AnchorLink, { anchor: anchors.placeOrder, children: "links to code" }), "."] })] }), "\n", _jsxs(ReviewSection, { title: "Commits and diffs", children: [_jsx(_components.h2, { "data-review-block-index": "8", "data-review-block-tag": "h2", children: "Commits and diffs" }), _jsxs(_components.p, { "data-review-block-index": "9", "data-review-block-tag": "p", children: ["Review pins an exact base and head before the agent starts writing. Open\n", _jsx(_components.strong, { children: "Commits" }), " to see the change in author order. Expand the sample commit to see\nits files, then choose ", _jsx(_components.strong, { children: "Open diff" }), " to inspect only that commit."] }), _jsxs(_components.p, { "data-review-block-index": "10", "data-review-block-tag": "p", children: ["The ", _jsx(_components.strong, { children: "Diff" }), " tab shows the complete change between the pinned base and head.\nChoose ", _jsx(_components.strong, { children: "Review" }), " when you are ready to return to this tour."] }), _jsx(TutorialViewButton, { view: "commits", children: _jsx(_components.p, { "data-review-block-index": "11", "data-review-block-tag": "p", children: "Explore the sample commits" }) })] }), "\n", _jsxs(ReviewSection, { title: "Comments are threads", children: [_jsx(_components.h2, { "data-review-block-index": "12", "data-review-block-tag": "h2", children: "Comments are threads" }), _jsx(_components.p, { "data-review-block-index": "13", "data-review-block-tag": "p", children: "You can attach a thread to any part of the canvas. Move the pointer over the\ncode below, select the comment control in the left gutter, and write a note." }), _jsx(CodePeek, { anchor: anchors.validateInventory }), _jsxs(_components.p, { "data-review-block-index": "14", "data-review-block-tag": "p", children: ["Choose ", _jsx(_components.strong, { children: "Ask now" }), ". The app starts an agent turn in a read-only checkout and\nputs its answer in the same thread. You can continue the conversation there."] }), _jsxs(_components.p, { "data-review-block-index": "15", "data-review-block-tag": "p", children: ["The other standard choice, ", _jsx(_components.strong, { children: "Add to review" }), ", holds feedback for the next\nauthoring round. This tour uses ", _jsx(_components.strong, { children: "Ask now" }), " so you can see the agent reply\nimmediately."] }), _jsxs(_components.p, { "data-review-block-index": "16", "data-review-block-tag": "p", children: ["Every comment is a thread anchored to one part of the Review. Use the ", _jsx(_components.strong, { children: "+" }), "\nbutton in the toolbar to start a thread about the whole Review instead."] })] }), "\n", _jsxs(ReviewSection, { title: "Interactive Diagrams", children: [_jsx(_components.h2, { "data-review-block-index": "17", "data-review-block-tag": "h2", children: "Interactive Diagrams" }), _jsx(_components.p, { "data-review-block-index": "18", "data-review-block-tag": "p", children: "The sequence diagram connects the checkout request to fulfillment. Select any\nmessage to open its supporting code." }), _jsx(SequenceDiagram, { label: "Checkout to fulfillment", messages: checkoutSequence }), _jsx(_components.p, { "data-review-block-index": "19", "data-review-block-tag": "p", children: "The database view groups writes by use case. Its operations open code too." }), _jsxs(DatabaseLens, { title: "Order storage", stores, height: 440, children: [_jsx(DbUseCase, { id: "create-order", label: "Create an order", children: _jsx(DbWrite, { from: actors.orderService, to: stores.orderDatabase.tables.orders.status, label: "write pending order", anchor: anchors.insertOrder }) }), _jsx(DbUseCase, { id: "fulfill-order", label: "Fulfill an order", children: _jsx(DbWrite, { from: actors.worker, to: stores.orderDatabase.tables.orders.status, label: "write fulfilled status", anchor: anchors.ship }) })] }), _jsxs(TutorialFeature, { feature: "softwareMap", children: [_jsxs(_components.p, { "data-review-block-index": "20", "data-review-block-tag": "p", children: ["The experimental ", _jsx(_components.strong, { children: "Map" }), " moves from the order system to its components and\ncode. Select a node to explore the sample service."] }), _jsx(TutorialViewButton, { view: "map", children: "Open the software map" })] })] }), "\n", _jsxs(ReviewSection, { title: "Get help", children: [_jsx(_components.h2, { "data-review-block-index": "21", "data-review-block-tag": "h2", children: "Get help" }), _jsxs(_components.p, { "data-review-block-index": "22", "data-review-block-tag": "p", children: ["To manage the Review skills installed for your agents, open ", _jsx(_components.strong, { children: "Preferences \u2192\nSettings" }), ". To revisit setup or take this tour again, open ", _jsx(_components.strong, { children: "Preferences \u2192\nGetting Started" }), "."] })] })] });
}
function MDXContent(props = {}) {
  const { wrapper: MDXLayout } = props.components || {};
  return MDXLayout ? _jsx(MDXLayout, { ...props, children: _jsx(_createMdxContent, { ...props }) }) : _createMdxContent(props);
}
function _missingMdxReference(id, component) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it.");
}
await __reviewDefinitionsReady();

// review-document:review:entry
import { createActiveReviewDocument } from "review-doc-runtime";
var activeReviewDocument = createActiveReviewDocument({
  slug: "",
  routePath: "/",
  filePath: "/var/folders/kv/_v5pszgx40q1w5y0j258cthw0000gn/T/review-tutorial-build-vuBYUH/reviews/21c4ba2e-9712-4606-85d4-23f38daa6067/review.mdx",
  title: "Review Desktop: three-minute tour",
  modelNames: [],
  models: review_document_exports,
  Component: MDXContent,
  isDefault: true
});
export {
  activeReviewDocument
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsicmV2aWV3LWRvY3VtZW50OnJldmlldzpkb2N1bWVudCIsICJyZXZpZXctZG9jdW1lbnQ6dmlydHVhbDpwcm9ncmVzc2l2ZS1yZXZpZXctYXV0aG9yaW5nIiwgImF1dGhvcmluZy1jb252ZXJzYXRpb24uanNvbiIsICJkYXRhLnRzIiwgInJldmlldy1kb2N1bWVudDpyZXZpZXc6ZW50cnkiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7XG4gIGNhbGxzLFxuICBkZWZpbmVBY3RvcnMsXG4gIGRlZmluZUFuY2hvcnMsXG4gIGRlZmluZVNvZnR3YXJlQWN0b3JzLFxuICBkZWZpbmVTb2Z0d2FyZU1vZGVsLFxuICBkZWZpbmVTb2Z0d2FyZVN0b3JlcyxcbiAgZGVmaW5lU3RvcmVzLFxuICBfX3Jldmlld0RlZmluaXRpb25zUmVhZHksXG59IGZyb20gXCJ2aXJ0dWFsOnByb2dyZXNzaXZlLXJldmlldy1hdXRob3JpbmdcIjtcblxuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMsIEZyYWdtZW50IGFzIF9GcmFnbWVudCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuaW1wb3J0IHsgYWN0b3JzLCBhbmNob3JzLCBhdXRob3JpbmdDb252ZXJzYXRpb24sIGNoZWNrb3V0U2VxdWVuY2UsIHN0b3JlcyB9IGZyb20gXCIuL2RhdGEudHNcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gICAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgICAgIGgxOiBcImgxXCIsXG4gICAgICAgIGgyOiBcImgyXCIsXG4gICAgICAgIGgzOiBcImgzXCIsXG4gICAgICAgIHA6IFwicFwiLFxuICAgICAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgICB9LCB7IEFuY2hvckxpbmssIENvZGVQZWVrLCBEYXRhYmFzZUxlbnMsIERiVXNlQ2FzZSwgRGJXcml0ZSwgUmV2aWV3U2VjdGlvbiwgU2VxdWVuY2VEaWFncmFtLCBUdXRvcmlhbEF1dGhvcmluZ0NvbnZlcnNhdGlvbiwgVHV0b3JpYWxGZWF0dXJlLCBUdXRvcmlhbEtleW1hcFBpY2tlciwgVHV0b3JpYWxWaWV3QnV0dG9uIH0gPSBfY29tcG9uZW50cztcbiAgICBpZiAoIUFuY2hvckxpbmspXG4gICAgICAgIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiQW5jaG9yTGlua1wiLCB0cnVlKTtcbiAgICBpZiAoIUNvZGVQZWVrKVxuICAgICAgICBfbWlzc2luZ01keFJlZmVyZW5jZShcIkNvZGVQZWVrXCIsIHRydWUpO1xuICAgIGlmICghRGF0YWJhc2VMZW5zKVxuICAgICAgICBfbWlzc2luZ01keFJlZmVyZW5jZShcIkRhdGFiYXNlTGVuc1wiLCB0cnVlKTtcbiAgICBpZiAoIURiVXNlQ2FzZSlcbiAgICAgICAgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJEYlVzZUNhc2VcIiwgdHJ1ZSk7XG4gICAgaWYgKCFEYldyaXRlKVxuICAgICAgICBfbWlzc2luZ01keFJlZmVyZW5jZShcIkRiV3JpdGVcIiwgdHJ1ZSk7XG4gICAgaWYgKCFSZXZpZXdTZWN0aW9uKVxuICAgICAgICBfbWlzc2luZ01keFJlZmVyZW5jZShcIlJldmlld1NlY3Rpb25cIiwgdHJ1ZSk7XG4gICAgaWYgKCFTZXF1ZW5jZURpYWdyYW0pXG4gICAgICAgIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiU2VxdWVuY2VEaWFncmFtXCIsIHRydWUpO1xuICAgIGlmICghVHV0b3JpYWxBdXRob3JpbmdDb252ZXJzYXRpb24pXG4gICAgICAgIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiVHV0b3JpYWxBdXRob3JpbmdDb252ZXJzYXRpb25cIiwgdHJ1ZSk7XG4gICAgaWYgKCFUdXRvcmlhbEZlYXR1cmUpXG4gICAgICAgIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiVHV0b3JpYWxGZWF0dXJlXCIsIHRydWUpO1xuICAgIGlmICghVHV0b3JpYWxLZXltYXBQaWNrZXIpXG4gICAgICAgIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiVHV0b3JpYWxLZXltYXBQaWNrZXJcIiwgdHJ1ZSk7XG4gICAgaWYgKCFUdXRvcmlhbFZpZXdCdXR0b24pXG4gICAgICAgIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiVHV0b3JpYWxWaWV3QnV0dG9uXCIsIHRydWUpO1xuICAgIHJldHVybiBfanN4cyhfRnJhZ21lbnQsIHsgY2hpbGRyZW46IFtfanN4KF9jb21wb25lbnRzLmgxLCB7IFwiZGF0YS1yZXZpZXctYmxvY2staW5kZXhcIjogXCIwXCIsIFwiZGF0YS1yZXZpZXctYmxvY2stdGFnXCI6IFwiaDFcIiwgY2hpbGRyZW46IFwiUmV2aWV3IERlc2t0b3A6IHRocmVlLW1pbnV0ZSB0b3VyXCIgfSksIFwiXFxuXCIsIF9qc3hzKFJldmlld1NlY3Rpb24sIHsgdGl0bGU6IFwiV2VsY29tZVwiLCBjaGlsZHJlbjogW19qc3goX2NvbXBvbmVudHMuaDIsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjFcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJoMlwiLCBjaGlsZHJlbjogXCJXZWxjb21lXCIgfSksIF9qc3goX2NvbXBvbmVudHMucCwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMlwiLCBcImRhdGEtcmV2aWV3LWJsb2NrLXRhZ1wiOiBcInBcIiwgY2hpbGRyZW46IFwiQSBSZXZpZXcgaXMgYSBndWlkZWQsIGludGVyYWN0aXZlIGV4cGxhbmF0aW9uIG9mIGEgY29kZSBjaGFuZ2UuIFRoZSBkb2N1bWVudFxcbmtlZXBzIHRoZSBpbXBvcnRhbnQgY29kZSwgc3lzdGVtIHZpZXdzLCBhbmQgZmVlZGJhY2sgaW4gb25lIHBsYWNlLlwiIH0pLCBfanN4KFR1dG9yaWFsQXV0aG9yaW5nQ29udmVyc2F0aW9uLCB7IGNvbnZlcnNhdGlvbjogYXV0aG9yaW5nQ29udmVyc2F0aW9uIH0pLCBfanN4KF9jb21wb25lbnRzLmgzLCB7IFwiZGF0YS1yZXZpZXctYmxvY2staW5kZXhcIjogXCIzXCIsIFwiZGF0YS1yZXZpZXctYmxvY2stdGFnXCI6IFwiaDNcIiwgY2hpbGRyZW46IFwiWW91ciBrZXliaW5kaW5nc1wiIH0pLCBfanN4KF9jb21wb25lbnRzLnAsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjRcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBcIkNob29zZSB5b3VyIGVkaXRvciBrZXlzLiBSZXZpZXcgaGlnaGxpZ2h0cyB0aGUgYWN0aXZlIGNob2ljZSBhbmQgdXNlcyBpdHNcXG5leGlzdGluZyBleHRlbnNpb24gYW5kIHJlbG9hZCBmbG93IGZvciBWaW0gYW5kIEVtYWNzLlwiIH0pLCBfanN4KFR1dG9yaWFsS2V5bWFwUGlja2VyLCB7fSksIF9qc3goX2NvbXBvbmVudHMuaDMsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjVcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJoM1wiLCBjaGlsZHJlbjogXCJQdXQgdGhlIGtleWJpbmRpbmdzIHRvIHdvcmtcIiB9KSwgX2pzeHMoX2NvbXBvbmVudHMucCwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiNlwiLCBcImRhdGEtcmV2aWV3LWJsb2NrLXRhZ1wiOiBcInBcIiwgY2hpbGRyZW46IFtcIlRoZSBlZGl0b3IgYmVsb3cgaXMgbGl2ZS4gVHJ5IGhvdmVyLCBcIiwgX2pzeChfY29tcG9uZW50cy5zdHJvbmcsIHsgY2hpbGRyZW46IFwiR28gdG8gRGVmaW5pdGlvblwiIH0pLCBcIiwgb3IgXCIsIF9qc3goX2NvbXBvbmVudHMuc3Ryb25nLCB7IGNoaWxkcmVuOiBcIkdvIHRvXFxuUmVmZXJlbmNlc1wiIH0pLCBcIiB3aXRoIHRoZSBzYW1lIGNvbW1hbmRzIHlvdSB1c2UgaW4gVlMgQ29kZS5cIl0gfSksIF9qc3goQ29kZVBlZWssIHsgYW5jaG9yOiBhbmNob3JzLnBsYWNlT3JkZXIgfSksIF9qc3hzKF9jb21wb25lbnRzLnAsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjdcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBbXCJQcm9zZSBpbiB0aGUgcmV2aWV3IGFsc28gc3VwcG9ydHMgXCIsIF9qc3goQW5jaG9yTGluaywgeyBhbmNob3I6IGFuY2hvcnMucGxhY2VPcmRlciwgY2hpbGRyZW46IFwibGlua3MgdG8gY29kZVwiIH0pLCBcIi5cIl0gfSldIH0pLCBcIlxcblwiLCBfanN4cyhSZXZpZXdTZWN0aW9uLCB7IHRpdGxlOiBcIkNvbW1pdHMgYW5kIGRpZmZzXCIsIGNoaWxkcmVuOiBbX2pzeChfY29tcG9uZW50cy5oMiwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiOFwiLCBcImRhdGEtcmV2aWV3LWJsb2NrLXRhZ1wiOiBcImgyXCIsIGNoaWxkcmVuOiBcIkNvbW1pdHMgYW5kIGRpZmZzXCIgfSksIF9qc3hzKF9jb21wb25lbnRzLnAsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjlcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBbXCJSZXZpZXcgcGlucyBhbiBleGFjdCBiYXNlIGFuZCBoZWFkIGJlZm9yZSB0aGUgYWdlbnQgc3RhcnRzIHdyaXRpbmcuIE9wZW5cXG5cIiwgX2pzeChfY29tcG9uZW50cy5zdHJvbmcsIHsgY2hpbGRyZW46IFwiQ29tbWl0c1wiIH0pLCBcIiB0byBzZWUgdGhlIGNoYW5nZSBpbiBhdXRob3Igb3JkZXIuIEV4cGFuZCB0aGUgc2FtcGxlIGNvbW1pdCB0byBzZWVcXG5pdHMgZmlsZXMsIHRoZW4gY2hvb3NlIFwiLCBfanN4KF9jb21wb25lbnRzLnN0cm9uZywgeyBjaGlsZHJlbjogXCJPcGVuIGRpZmZcIiB9KSwgXCIgdG8gaW5zcGVjdCBvbmx5IHRoYXQgY29tbWl0LlwiXSB9KSwgX2pzeHMoX2NvbXBvbmVudHMucCwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMTBcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBbXCJUaGUgXCIsIF9qc3goX2NvbXBvbmVudHMuc3Ryb25nLCB7IGNoaWxkcmVuOiBcIkRpZmZcIiB9KSwgXCIgdGFiIHNob3dzIHRoZSBjb21wbGV0ZSBjaGFuZ2UgYmV0d2VlbiB0aGUgcGlubmVkIGJhc2UgYW5kIGhlYWQuXFxuQ2hvb3NlIFwiLCBfanN4KF9jb21wb25lbnRzLnN0cm9uZywgeyBjaGlsZHJlbjogXCJSZXZpZXdcIiB9KSwgXCIgd2hlbiB5b3UgYXJlIHJlYWR5IHRvIHJldHVybiB0byB0aGlzIHRvdXIuXCJdIH0pLCBfanN4KFR1dG9yaWFsVmlld0J1dHRvbiwgeyB2aWV3OiBcImNvbW1pdHNcIiwgY2hpbGRyZW46IF9qc3goX2NvbXBvbmVudHMucCwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMTFcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBcIkV4cGxvcmUgdGhlIHNhbXBsZSBjb21taXRzXCIgfSkgfSldIH0pLCBcIlxcblwiLCBfanN4cyhSZXZpZXdTZWN0aW9uLCB7IHRpdGxlOiBcIkNvbW1lbnRzIGFyZSB0aHJlYWRzXCIsIGNoaWxkcmVuOiBbX2pzeChfY29tcG9uZW50cy5oMiwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMTJcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJoMlwiLCBjaGlsZHJlbjogXCJDb21tZW50cyBhcmUgdGhyZWFkc1wiIH0pLCBfanN4KF9jb21wb25lbnRzLnAsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjEzXCIsIFwiZGF0YS1yZXZpZXctYmxvY2stdGFnXCI6IFwicFwiLCBjaGlsZHJlbjogXCJZb3UgY2FuIGF0dGFjaCBhIHRocmVhZCB0byBhbnkgcGFydCBvZiB0aGUgY2FudmFzLiBNb3ZlIHRoZSBwb2ludGVyIG92ZXIgdGhlXFxuY29kZSBiZWxvdywgc2VsZWN0IHRoZSBjb21tZW50IGNvbnRyb2wgaW4gdGhlIGxlZnQgZ3V0dGVyLCBhbmQgd3JpdGUgYSBub3RlLlwiIH0pLCBfanN4KENvZGVQZWVrLCB7IGFuY2hvcjogYW5jaG9ycy52YWxpZGF0ZUludmVudG9yeSB9KSwgX2pzeHMoX2NvbXBvbmVudHMucCwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMTRcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBbXCJDaG9vc2UgXCIsIF9qc3goX2NvbXBvbmVudHMuc3Ryb25nLCB7IGNoaWxkcmVuOiBcIkFzayBub3dcIiB9KSwgXCIuIFRoZSBhcHAgc3RhcnRzIGFuIGFnZW50IHR1cm4gaW4gYSByZWFkLW9ubHkgY2hlY2tvdXQgYW5kXFxucHV0cyBpdHMgYW5zd2VyIGluIHRoZSBzYW1lIHRocmVhZC4gWW91IGNhbiBjb250aW51ZSB0aGUgY29udmVyc2F0aW9uIHRoZXJlLlwiXSB9KSwgX2pzeHMoX2NvbXBvbmVudHMucCwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMTVcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBbXCJUaGUgb3RoZXIgc3RhbmRhcmQgY2hvaWNlLCBcIiwgX2pzeChfY29tcG9uZW50cy5zdHJvbmcsIHsgY2hpbGRyZW46IFwiQWRkIHRvIHJldmlld1wiIH0pLCBcIiwgaG9sZHMgZmVlZGJhY2sgZm9yIHRoZSBuZXh0XFxuYXV0aG9yaW5nIHJvdW5kLiBUaGlzIHRvdXIgdXNlcyBcIiwgX2pzeChfY29tcG9uZW50cy5zdHJvbmcsIHsgY2hpbGRyZW46IFwiQXNrIG5vd1wiIH0pLCBcIiBzbyB5b3UgY2FuIHNlZSB0aGUgYWdlbnQgcmVwbHlcXG5pbW1lZGlhdGVseS5cIl0gfSksIF9qc3hzKF9jb21wb25lbnRzLnAsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjE2XCIsIFwiZGF0YS1yZXZpZXctYmxvY2stdGFnXCI6IFwicFwiLCBjaGlsZHJlbjogW1wiRXZlcnkgY29tbWVudCBpcyBhIHRocmVhZCBhbmNob3JlZCB0byBvbmUgcGFydCBvZiB0aGUgUmV2aWV3LiBVc2UgdGhlIFwiLCBfanN4KF9jb21wb25lbnRzLnN0cm9uZywgeyBjaGlsZHJlbjogXCIrXCIgfSksIFwiXFxuYnV0dG9uIGluIHRoZSB0b29sYmFyIHRvIHN0YXJ0IGEgdGhyZWFkIGFib3V0IHRoZSB3aG9sZSBSZXZpZXcgaW5zdGVhZC5cIl0gfSldIH0pLCBcIlxcblwiLCBfanN4cyhSZXZpZXdTZWN0aW9uLCB7IHRpdGxlOiBcIkludGVyYWN0aXZlIERpYWdyYW1zXCIsIGNoaWxkcmVuOiBbX2pzeChfY29tcG9uZW50cy5oMiwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMTdcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJoMlwiLCBjaGlsZHJlbjogXCJJbnRlcmFjdGl2ZSBEaWFncmFtc1wiIH0pLCBfanN4KF9jb21wb25lbnRzLnAsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjE4XCIsIFwiZGF0YS1yZXZpZXctYmxvY2stdGFnXCI6IFwicFwiLCBjaGlsZHJlbjogXCJUaGUgc2VxdWVuY2UgZGlhZ3JhbSBjb25uZWN0cyB0aGUgY2hlY2tvdXQgcmVxdWVzdCB0byBmdWxmaWxsbWVudC4gU2VsZWN0IGFueVxcbm1lc3NhZ2UgdG8gb3BlbiBpdHMgc3VwcG9ydGluZyBjb2RlLlwiIH0pLCBfanN4KFNlcXVlbmNlRGlhZ3JhbSwgeyBsYWJlbDogXCJDaGVja291dCB0byBmdWxmaWxsbWVudFwiLCBtZXNzYWdlczogY2hlY2tvdXRTZXF1ZW5jZSB9KSwgX2pzeChfY29tcG9uZW50cy5wLCB7IFwiZGF0YS1yZXZpZXctYmxvY2staW5kZXhcIjogXCIxOVwiLCBcImRhdGEtcmV2aWV3LWJsb2NrLXRhZ1wiOiBcInBcIiwgY2hpbGRyZW46IFwiVGhlIGRhdGFiYXNlIHZpZXcgZ3JvdXBzIHdyaXRlcyBieSB1c2UgY2FzZS4gSXRzIG9wZXJhdGlvbnMgb3BlbiBjb2RlIHRvby5cIiB9KSwgX2pzeHMoRGF0YWJhc2VMZW5zLCB7IHRpdGxlOiBcIk9yZGVyIHN0b3JhZ2VcIiwgc3RvcmVzOiBzdG9yZXMsIGhlaWdodDogNDQwLCBjaGlsZHJlbjogW19qc3goRGJVc2VDYXNlLCB7IGlkOiBcImNyZWF0ZS1vcmRlclwiLCBsYWJlbDogXCJDcmVhdGUgYW4gb3JkZXJcIiwgY2hpbGRyZW46IF9qc3goRGJXcml0ZSwgeyBmcm9tOiBhY3RvcnMub3JkZXJTZXJ2aWNlLCB0bzogc3RvcmVzLm9yZGVyRGF0YWJhc2UudGFibGVzLm9yZGVycy5zdGF0dXMsIGxhYmVsOiBcIndyaXRlIHBlbmRpbmcgb3JkZXJcIiwgYW5jaG9yOiBhbmNob3JzLmluc2VydE9yZGVyIH0pIH0pLCBfanN4KERiVXNlQ2FzZSwgeyBpZDogXCJmdWxmaWxsLW9yZGVyXCIsIGxhYmVsOiBcIkZ1bGZpbGwgYW4gb3JkZXJcIiwgY2hpbGRyZW46IF9qc3goRGJXcml0ZSwgeyBmcm9tOiBhY3RvcnMud29ya2VyLCB0bzogc3RvcmVzLm9yZGVyRGF0YWJhc2UudGFibGVzLm9yZGVycy5zdGF0dXMsIGxhYmVsOiBcIndyaXRlIGZ1bGZpbGxlZCBzdGF0dXNcIiwgYW5jaG9yOiBhbmNob3JzLnNoaXAgfSkgfSldIH0pLCBfanN4cyhUdXRvcmlhbEZlYXR1cmUsIHsgZmVhdHVyZTogXCJzb2Z0d2FyZU1hcFwiLCBjaGlsZHJlbjogW19qc3hzKF9jb21wb25lbnRzLnAsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjIwXCIsIFwiZGF0YS1yZXZpZXctYmxvY2stdGFnXCI6IFwicFwiLCBjaGlsZHJlbjogW1wiVGhlIGV4cGVyaW1lbnRhbCBcIiwgX2pzeChfY29tcG9uZW50cy5zdHJvbmcsIHsgY2hpbGRyZW46IFwiTWFwXCIgfSksIFwiIG1vdmVzIGZyb20gdGhlIG9yZGVyIHN5c3RlbSB0byBpdHMgY29tcG9uZW50cyBhbmRcXG5jb2RlLiBTZWxlY3QgYSBub2RlIHRvIGV4cGxvcmUgdGhlIHNhbXBsZSBzZXJ2aWNlLlwiXSB9KSwgX2pzeChUdXRvcmlhbFZpZXdCdXR0b24sIHsgdmlldzogXCJtYXBcIiwgY2hpbGRyZW46IFwiT3BlbiB0aGUgc29mdHdhcmUgbWFwXCIgfSldIH0pXSB9KSwgXCJcXG5cIiwgX2pzeHMoUmV2aWV3U2VjdGlvbiwgeyB0aXRsZTogXCJHZXQgaGVscFwiLCBjaGlsZHJlbjogW19qc3goX2NvbXBvbmVudHMuaDIsIHsgXCJkYXRhLXJldmlldy1ibG9jay1pbmRleFwiOiBcIjIxXCIsIFwiZGF0YS1yZXZpZXctYmxvY2stdGFnXCI6IFwiaDJcIiwgY2hpbGRyZW46IFwiR2V0IGhlbHBcIiB9KSwgX2pzeHMoX2NvbXBvbmVudHMucCwgeyBcImRhdGEtcmV2aWV3LWJsb2NrLWluZGV4XCI6IFwiMjJcIiwgXCJkYXRhLXJldmlldy1ibG9jay10YWdcIjogXCJwXCIsIGNoaWxkcmVuOiBbXCJUbyBtYW5hZ2UgdGhlIFJldmlldyBza2lsbHMgaW5zdGFsbGVkIGZvciB5b3VyIGFnZW50cywgb3BlbiBcIiwgX2pzeChfY29tcG9uZW50cy5zdHJvbmcsIHsgY2hpbGRyZW46IFwiUHJlZmVyZW5jZXMgXHUyMTkyXFxuU2V0dGluZ3NcIiB9KSwgXCIuIFRvIHJldmlzaXQgc2V0dXAgb3IgdGFrZSB0aGlzIHRvdXIgYWdhaW4sIG9wZW4gXCIsIF9qc3goX2NvbXBvbmVudHMuc3Ryb25nLCB7IGNoaWxkcmVuOiBcIlByZWZlcmVuY2VzIFx1MjE5MlxcbkdldHRpbmcgU3RhcnRlZFwiIH0pLCBcIi5cIl0gfSldIH0pXSB9KTtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICAgIGNvbnN0IHsgd3JhcHBlcjogTURYTGF5b3V0IH0gPSBwcm9wcy5jb21wb25lbnRzIHx8ICh7fSk7XG4gICAgcmV0dXJuIE1EWExheW91dCA/IF9qc3goTURYTGF5b3V0LCB7IC4uLnByb3BzLCBjaGlsZHJlbjogX2pzeChfY3JlYXRlTWR4Q29udGVudCwgeyAuLi5wcm9wcyB9KSB9KSA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIpO1xufVxuXG5hd2FpdCBfX3Jldmlld0RlZmluaXRpb25zUmVhZHkoKTtcbiIsICJpbXBvcnQgeyBjYWxscywgY3JlYXRlQnJvd3NlclJldmlld0RlZmluaXRpb25TZXNzaW9uLCBkZWZpbmVTb2Z0d2FyZU1vZGVsIH0gZnJvbSBcInJldmlldy1kb2MtcnVudGltZVwiO1xuY29uc3Qgc2Vzc2lvbiA9IGNyZWF0ZUJyb3dzZXJSZXZpZXdEZWZpbml0aW9uU2Vzc2lvbih7XG4gIHJvdXRlUGF0aDogXCIvXCIsXG4gIHNvZnR3YXJlTWFwOiBudWxsLFxuICBiYXNlU29mdHdhcmVNYXA6IG51bGwsXG59KTtcbnNlc3Npb24uYmVnaW4oKTtcbmV4cG9ydCB7IGNhbGxzLCBkZWZpbmVTb2Z0d2FyZU1vZGVsIH07XG5leHBvcnQgY29uc3QgZGVmaW5lQWN0b3JzID0gc2Vzc2lvbi5kZWZpbmVBY3RvcnM7XG5leHBvcnQgY29uc3QgZGVmaW5lQW5jaG9ycyA9IHNlc3Npb24uZGVmaW5lQW5jaG9ycztcbmV4cG9ydCBjb25zdCBkZWZpbmVTdG9yZXMgPSBzZXNzaW9uLmRlZmluZVN0b3JlcztcbmV4cG9ydCBjb25zdCBkZWZpbmVTb2Z0d2FyZUFjdG9ycyA9IHNlc3Npb24uZGVmaW5lU29mdHdhcmVBY3RvcnM7XG5leHBvcnQgY29uc3QgZGVmaW5lU29mdHdhcmVTdG9yZXMgPSBzZXNzaW9uLmRlZmluZVNvZnR3YXJlU3RvcmVzO1xuZXhwb3J0IGNvbnN0IF9fcmV2aWV3RGVmaW5pdGlvbnNSZWFkeSA9IHNlc3Npb24ucmVhZHk7IiwgIntcbiAgXCJ2ZXJzaW9uXCI6IDEsXG4gIFwidGl0bGVcIjogXCJIb3cgdGhpcyBSZXZpZXcgd2FzIG1hZGVcIixcbiAgXCJtZXNzYWdlc1wiOiBbXG4gICAge1xuICAgICAgXCJyb2xlXCI6IFwidXNlclwiLFxuICAgICAgXCJib2R5XCI6IFwiL2Rldi1yZXZpZXcgSSdkIGxpa2UgdG8gcmV2aWV3IHRoZSBmZWF0dXJlIHdlIGp1c3Qgd29ya2VkIG9uLlwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcInJvbGVcIjogXCJhc3Npc3RhbnRcIixcbiAgICAgIFwiYm9keVwiOiBcIk9rLCBJJ20gb24gaXQuLi5cIlxuICAgIH1cbiAgXVxufVxuIiwgImltcG9ydCB0eXBlIHsgVHV0b3JpYWxBdXRob3JpbmdDb252ZXJzYXRpb24gfSBmcm9tIFwiQGRldi5mYXN0L3Jldmlldy9hdXRob3JpbmdcIjtcbmltcG9ydCB7XG4gIGRlZmluZUFjdG9ycyxcbiAgZGVmaW5lQW5jaG9ycyxcbiAgZGVmaW5lU3RvcmVzLFxufSBmcm9tIFwidmlydHVhbDpwcm9ncmVzc2l2ZS1yZXZpZXctYXV0aG9yaW5nXCI7XG5cbmltcG9ydCBhdXRob3JpbmdDb252ZXJzYXRpb25JbnB1dCBmcm9tIFwiLi9hdXRob3JpbmctY29udmVyc2F0aW9uLmpzb25cIjtcblxuLy8gU0FGRVRZOiBzY3JpcHRzL2NoZWNrLXR1dG9yaWFsLnRzIHBhcnNlcyBhdXRob3JpbmctY29udmVyc2F0aW9uLmpzb24gd2l0aFxuLy8gdHV0b3JpYWxBdXRob3JpbmdDb252ZXJzYXRpb25TY2hlbWEgaW4gQ0ksIHdoaWNoIHBpbnMgdmVyc2lvbiB0byAxIGFuZCByb2xlXG4vLyB0byBcInVzZXJcIiB8IFwiYXNzaXN0YW50XCI7IHRoZSBKU09OIGltcG9ydCBvbmx5IHdpZGVucyB0aG9zZSBsaXRlcmFscy5cbmV4cG9ydCBjb25zdCBhdXRob3JpbmdDb252ZXJzYXRpb246IFR1dG9yaWFsQXV0aG9yaW5nQ29udmVyc2F0aW9uID0ge1xuICB2ZXJzaW9uOiBhdXRob3JpbmdDb252ZXJzYXRpb25JbnB1dC52ZXJzaW9uIGFzIDEsXG4gIHRpdGxlOiBhdXRob3JpbmdDb252ZXJzYXRpb25JbnB1dC50aXRsZSxcbiAgbWVzc2FnZXM6IGF1dGhvcmluZ0NvbnZlcnNhdGlvbklucHV0Lm1lc3NhZ2VzLm1hcCgobWVzc2FnZSkgPT4gKHtcbiAgICByb2xlOiBtZXNzYWdlLnJvbGUgYXMgXCJ1c2VyXCIgfCBcImFzc2lzdGFudFwiLFxuICAgIGJvZHk6IG1lc3NhZ2UuYm9keSxcbiAgfSkpLFxufTtcblxuZXhwb3J0IGNvbnN0IGFuY2hvcnMgPSBkZWZpbmVBbmNob3JzKHtcbiAgY2hlY2tvdXQ6IHtcbiAgICB0aXRsZTogXCJDaGVja291dCBBUEkgY2FsbHMgdGhlIG9yZGVyIHNlcnZpY2VcIixcbiAgICBwZWVrOiB7IGZpbGU6IFwic3JjL2FwaS9jaGVja291dC1hcGkudHNcIiwgZnJvbUxpbmU6IDEyLCB0b0xpbmU6IDE1IH0sXG4gICAgc29mdHdhcmVNYXBQYXRoOiBcIm9yZGVyU2VydmljZS5hcGkuY2hlY2tvdXRcIixcbiAgfSxcbiAgcGxhY2VPcmRlcjoge1xuICAgIHRpdGxlOiBcIk9yZGVyIHNlcnZpY2UgY3JlYXRlcyB0aGUgb3JkZXJcIixcbiAgICBwZWVrOiB7IGZpbGU6IFwic3JjL29yZGVycy9vcmRlci1zZXJ2aWNlLnRzXCIsIGZyb21MaW5lOiAxMywgdG9MaW5lOiAyOSB9LFxuICAgIHNvZnR3YXJlTWFwUGF0aDogXCJvcmRlclNlcnZpY2UuYXBwbGljYXRpb24ub3JkZXJzXCIsXG4gIH0sXG4gIGluc2VydE9yZGVyOiB7XG4gICAgdGl0bGU6IFwiUmVwb3NpdG9yeSB3cml0ZXMgYW5kIHF1ZXVlcyB0aGUgb3JkZXJcIixcbiAgICBwZWVrOiB7IGZpbGU6IFwic3JjL29yZGVycy9vcmRlcnMtcmVwb3NpdG9yeS50c1wiLCBmcm9tTGluZTogOSwgdG9MaW5lOiAxMiB9LFxuICAgIHNvZnR3YXJlTWFwUGF0aDogXCJvcmRlclNlcnZpY2UuZGF0YS5vcmRlcnNSZXBvc2l0b3J5XCIsXG4gIH0sXG4gIHZhbGlkYXRlSW52ZW50b3J5OiB7XG4gICAgdGl0bGU6IFwiSW52ZW50b3J5IHJlamVjdHMgaW52YWxpZCBxdWFudGl0aWVzXCIsXG4gICAgcGVlazoge1xuICAgICAgZmlsZTogXCJzcmMvaW52ZW50b3J5L2ludmVudG9yeS1zZXJ2aWNlLnRzXCIsXG4gICAgICBmcm9tTGluZTogNCxcbiAgICAgIHRvTGluZTogOCxcbiAgICB9LFxuICAgIHNvZnR3YXJlTWFwUGF0aDogXCJvcmRlclNlcnZpY2UuYXBwbGljYXRpb24ub3JkZXJzXCIsXG4gIH0sXG4gIGRlcXVldWU6IHtcbiAgICB0aXRsZTogXCJRdWV1ZSBnaXZlcyB3b3JrIHRvIHRoZSBmdWxmaWxsbWVudCB3b3JrZXJcIixcbiAgICBwZWVrOiB7XG4gICAgICBmaWxlOiBcInNyYy9mdWxmaWxsbWVudC9mdWxmaWxsbWVudC13b3JrZXIudHNcIixcbiAgICAgIGZyb21MaW5lOiAxMyxcbiAgICAgIHRvTGluZTogMTQsXG4gICAgfSxcbiAgICBzb2Z0d2FyZU1hcFBhdGg6IFwib3JkZXJTZXJ2aWNlLmZ1bGZpbGxtZW50LndvcmtlclwiLFxuICB9LFxuICBzaGlwOiB7XG4gICAgdGl0bGU6IFwiV29ya2VyIGNyZWF0ZXMgdGhlIHNoaXBtZW50XCIsXG4gICAgcGVlazoge1xuICAgICAgZmlsZTogXCJzcmMvZnVsZmlsbG1lbnQvZnVsZmlsbG1lbnQtd29ya2VyLnRzXCIsXG4gICAgICBmcm9tTGluZTogMTcsXG4gICAgICB0b0xpbmU6IDE5LFxuICAgIH0sXG4gICAgc29mdHdhcmVNYXBQYXRoOiBcIm9yZGVyU2VydmljZS5mdWxmaWxsbWVudC53b3JrZXJcIixcbiAgfSxcbiAgb3JkZXJzVGFibGU6IHtcbiAgICB0aXRsZTogXCJPcmRlcnMgdGFibGVcIixcbiAgICBwZWVrOiB7IGZpbGU6IFwic3JjL2RhdGFiYXNlL3NjaGVtYS50c1wiLCBmcm9tTGluZTogMSwgdG9MaW5lOiAxMCB9LFxuICAgIHNvZnR3YXJlTWFwUGF0aDogXCJvcmRlclNlcnZpY2UuZGF0YS5vcmRlcnNEYXRhYmFzZVwiLFxuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBhY3RvcnMgPSBkZWZpbmVBY3RvcnMoe1xuICBjaGVja291dDoge1xuICAgIGxhYmVsOiBcIkNoZWNrb3V0IEFQSVwiLFxuICAgIHNvZnR3YXJlTWFwUGF0aDogXCJvcmRlclNlcnZpY2UuYXBpLmNoZWNrb3V0XCIsXG4gIH0sXG4gIG9yZGVyU2VydmljZToge1xuICAgIGxhYmVsOiBcIk9yZGVyIHNlcnZpY2VcIixcbiAgICBzb2Z0d2FyZU1hcFBhdGg6IFwib3JkZXJTZXJ2aWNlLmFwcGxpY2F0aW9uLm9yZGVyc1wiLFxuICB9LFxuICByZXBvc2l0b3J5OiB7XG4gICAgbGFiZWw6IFwiT3JkZXJzIHJlcG9zaXRvcnlcIixcbiAgICBzb2Z0d2FyZU1hcFBhdGg6IFwib3JkZXJTZXJ2aWNlLmRhdGEub3JkZXJzUmVwb3NpdG9yeVwiLFxuICB9LFxuICBxdWV1ZToge1xuICAgIGxhYmVsOiBcIkZ1bGZpbGxtZW50IHF1ZXVlXCIsXG4gICAgc29mdHdhcmVNYXBQYXRoOiBcIm9yZGVyU2VydmljZS5mdWxmaWxsbWVudC5xdWV1ZVwiLFxuICB9LFxuICB3b3JrZXI6IHtcbiAgICBsYWJlbDogXCJGdWxmaWxsbWVudCB3b3JrZXJcIixcbiAgICBzb2Z0d2FyZU1hcFBhdGg6IFwib3JkZXJTZXJ2aWNlLmZ1bGZpbGxtZW50LndvcmtlclwiLFxuICB9LFxuICBzaGlwcGluZzoge1xuICAgIGxhYmVsOiBcIlNoaXBwaW5nIGdhdGV3YXlcIixcbiAgICBzb2Z0d2FyZU1hcFBhdGg6IFwib3JkZXJTZXJ2aWNlLnNoaXBwaW5nLmdhdGV3YXlcIixcbiAgfSxcbn0pO1xuXG5leHBvcnQgY29uc3QgY2hlY2tvdXRTZXF1ZW5jZSA9IFtcbiAge1xuICAgIGZyb206IGFjdG9ycy5jaGVja291dCxcbiAgICB0bzogYWN0b3JzLm9yZGVyU2VydmljZSxcbiAgICBsYWJlbDogXCJQbGFjZSBvcmRlclwiLFxuICAgIGFuY2hvcjogYW5jaG9ycy5jaGVja291dCxcbiAgfSxcbiAge1xuICAgIGZyb206IGFjdG9ycy5vcmRlclNlcnZpY2UsXG4gICAgdG86IGFjdG9ycy5yZXBvc2l0b3J5LFxuICAgIGxhYmVsOiBcIlNhdmUgb3JkZXJcIixcbiAgICBhbmNob3I6IGFuY2hvcnMucGxhY2VPcmRlcixcbiAgfSxcbiAge1xuICAgIGZyb206IGFjdG9ycy5yZXBvc2l0b3J5LFxuICAgIHRvOiBhY3RvcnMucXVldWUsXG4gICAgbGFiZWw6IFwiRW5xdWV1ZSBmdWxmaWxsbWVudFwiLFxuICAgIGFuY2hvcjogYW5jaG9ycy5pbnNlcnRPcmRlcixcbiAgfSxcbiAge1xuICAgIGZyb206IGFjdG9ycy5xdWV1ZSxcbiAgICB0bzogYWN0b3JzLndvcmtlcixcbiAgICBsYWJlbDogXCJEZWxpdmVyIGpvYlwiLFxuICAgIGFuY2hvcjogYW5jaG9ycy5kZXF1ZXVlLFxuICB9LFxuICB7XG4gICAgZnJvbTogYWN0b3JzLndvcmtlcixcbiAgICB0bzogYWN0b3JzLnNoaXBwaW5nLFxuICAgIGxhYmVsOiBcIkNyZWF0ZSBzaGlwbWVudFwiLFxuICAgIGFuY2hvcjogYW5jaG9ycy5zaGlwLFxuICB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IHN0b3JlcyA9IGRlZmluZVN0b3Jlcyh7XG4gIG9yZGVyRGF0YWJhc2U6IHtcbiAgICBraW5kOiBcInJlbGF0aW9uYWxcIixcbiAgICBsYWJlbDogXCJPcmRlciBkYXRhYmFzZVwiLFxuICAgIHNvZnR3YXJlTWFwUGF0aDogXCJvcmRlclNlcnZpY2UuZGF0YS5vcmRlcnNEYXRhYmFzZVwiLFxuICAgIHRhYmxlczoge1xuICAgICAgb3JkZXJzOiB7XG4gICAgICAgIGxhYmVsOiBcIm9yZGVyc1wiLFxuICAgICAgICBzY2hlbWE6IHtcbiAgICAgICAgICBpZDogeyB0eXBlOiBcInRleHRcIiwgcGs6IHRydWUsIGV4YW1wbGU6IFwib3JkZXItY3VzdG9tZXItNDJcIiB9LFxuICAgICAgICAgIGN1c3RvbWVySWQ6IHsgdHlwZTogXCJ0ZXh0XCIsIGV4YW1wbGU6IFwiY3VzdG9tZXItNDJcIiB9LFxuICAgICAgICAgIHRvdGFsQ2VudHM6IHsgdHlwZTogXCJpbnRlZ2VyXCIsIGV4YW1wbGU6IDEyNTAwIH0sXG4gICAgICAgICAgc3RhdHVzOiB7IHR5cGU6IFwidGV4dFwiLCBleGFtcGxlOiBcImZ1bGZpbGxlZFwiIH0sXG4gICAgICAgICAgY3JlYXRlZEF0OiB7IHR5cGU6IFwidGltZXN0YW1wXCIsIGV4YW1wbGU6IFwiMjAyNi0wOC0xMFQxMjowMDowMFpcIiB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxufSk7XG4iLCAiaW1wb3J0ICogYXMgcmV2aWV3RG9jdW1lbnRNb2R1bGUgZnJvbSBcInJldmlldzpkb2N1bWVudFwiO1xuaW1wb3J0IHsgY3JlYXRlQWN0aXZlUmV2aWV3RG9jdW1lbnQgfSBmcm9tIFwicmV2aWV3LWRvYy1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgYWN0aXZlUmV2aWV3RG9jdW1lbnQgPSBjcmVhdGVBY3RpdmVSZXZpZXdEb2N1bWVudCh7XG4gIHNsdWc6IFwiXCIsXG4gIHJvdXRlUGF0aDogXCIvXCIsXG4gIGZpbGVQYXRoOiBcIi92YXIvZm9sZGVycy9rdi9fdjVwc3pneDQwcTF3NXkwajI1OGN0aHcwMDAwZ24vVC9yZXZpZXctdHV0b3JpYWwtYnVpbGQtdnVCWVVIL3Jldmlld3MvMjFjNGJhMmUtOTcxMi00NjA2LTg1ZDQtMjNmMzhkYWE2MDY3L3Jldmlldy5tZHhcIixcbiAgdGl0bGU6IFwiUmV2aWV3IERlc2t0b3A6IHRocmVlLW1pbnV0ZSB0b3VyXCIsXG4gIG1vZGVsTmFtZXM6IFtdLFxuICBtb2RlbHM6IHJldmlld0RvY3VtZW50TW9kdWxlLFxuICBDb21wb25lbnQ6IHJldmlld0RvY3VtZW50TW9kdWxlLmRlZmF1bHQsXG4gIGlzRGVmYXVsdDogdHJ1ZSxcbn0pOyJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7O0FDQUEsU0FBUyxPQUFPLHNDQUFzQywyQkFBMkI7QUFDakYsSUFBTSxVQUFVLHFDQUFxQztBQUFBLEVBQ25ELFdBQVc7QUFBQSxFQUNYLGFBQWE7QUFBQSxFQUNiLGlCQUFpQjtBQUNuQixDQUFDO0FBQ0QsUUFBUSxNQUFNO0FBRVAsSUFBTSxlQUFlLFFBQVE7QUFDN0IsSUFBTSxnQkFBZ0IsUUFBUTtBQUM5QixJQUFNLGVBQWUsUUFBUTtBQUM3QixJQUFNLHVCQUF1QixRQUFRO0FBQ3JDLElBQU0sdUJBQXVCLFFBQVE7QUFDckMsSUFBTSwyQkFBMkIsUUFBUTs7O0FERmhELFNBQVMsT0FBTyxNQUFNLFFBQVEsT0FBTyxZQUFZLGlCQUFpQjs7O0FFWGxFO0FBQUEsRUFDRSxTQUFXO0FBQUEsRUFDWCxPQUFTO0FBQUEsRUFDVCxVQUFZO0FBQUEsSUFDVjtBQUFBLE1BQ0UsTUFBUTtBQUFBLE1BQ1IsTUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFRO0FBQUEsTUFDUixNQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDRjs7O0FDRE8sSUFBTSx3QkFBdUQ7QUFBQSxFQUNsRSxTQUFTLCtCQUEyQjtBQUFBLEVBQ3BDLE9BQU8sK0JBQTJCO0FBQUEsRUFDbEMsVUFBVSwrQkFBMkIsU0FBUyxJQUFJLENBQUMsYUFBYTtBQUFBLElBQzlELE1BQU0sUUFBUTtBQUFBLElBQ2QsTUFBTSxRQUFRO0FBQUEsRUFDaEIsRUFBRTtBQUNKO0FBRU8sSUFBTSxVQUFVLGNBQWM7QUFBQSxFQUNuQyxVQUFVO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxNQUFNLEVBQUUsTUFBTSwyQkFBMkIsVUFBVSxJQUFJLFFBQVEsR0FBRztBQUFBLElBQ2xFLGlCQUFpQjtBQUFBLEVBQ25CO0FBQUEsRUFDQSxZQUFZO0FBQUEsSUFDVixPQUFPO0FBQUEsSUFDUCxNQUFNLEVBQUUsTUFBTSwrQkFBK0IsVUFBVSxJQUFJLFFBQVEsR0FBRztBQUFBLElBQ3RFLGlCQUFpQjtBQUFBLEVBQ25CO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxPQUFPO0FBQUEsSUFDUCxNQUFNLEVBQUUsTUFBTSxtQ0FBbUMsVUFBVSxHQUFHLFFBQVEsR0FBRztBQUFBLElBQ3pFLGlCQUFpQjtBQUFBLEVBQ25CO0FBQUEsRUFDQSxtQkFBbUI7QUFBQSxJQUNqQixPQUFPO0FBQUEsSUFDUCxNQUFNO0FBQUEsTUFDSixNQUFNO0FBQUEsTUFDTixVQUFVO0FBQUEsTUFDVixRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0EsaUJBQWlCO0FBQUEsRUFDbkI7QUFBQSxFQUNBLFNBQVM7QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxNQUNKLE1BQU07QUFBQSxNQUNOLFVBQVU7QUFBQSxNQUNWLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsTUFBTTtBQUFBLElBQ0osT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLE1BQ0osTUFBTTtBQUFBLE1BQ04sVUFBVTtBQUFBLE1BQ1YsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLEVBQ25CO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxPQUFPO0FBQUEsSUFDUCxNQUFNLEVBQUUsTUFBTSwwQkFBMEIsVUFBVSxHQUFHLFFBQVEsR0FBRztBQUFBLElBQ2hFLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0YsQ0FBQztBQUVNLElBQU0sU0FBUyxhQUFhO0FBQUEsRUFDakMsVUFBVTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsaUJBQWlCO0FBQUEsRUFDbkI7QUFBQSxFQUNBLGNBQWM7QUFBQSxJQUNaLE9BQU87QUFBQSxJQUNQLGlCQUFpQjtBQUFBLEVBQ25CO0FBQUEsRUFDQSxZQUFZO0FBQUEsSUFDVixPQUFPO0FBQUEsSUFDUCxpQkFBaUI7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsT0FBTztBQUFBLElBQ0wsT0FBTztBQUFBLElBQ1AsaUJBQWlCO0FBQUEsRUFDbkI7QUFBQSxFQUNBLFFBQVE7QUFBQSxJQUNOLE9BQU87QUFBQSxJQUNQLGlCQUFpQjtBQUFBLEVBQ25CO0FBQUEsRUFDQSxVQUFVO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxpQkFBaUI7QUFBQSxFQUNuQjtBQUNGLENBQUM7QUFFTSxJQUFNLG1CQUFtQjtBQUFBLEVBQzlCO0FBQUEsSUFDRSxNQUFNLE9BQU87QUFBQSxJQUNiLElBQUksT0FBTztBQUFBLElBQ1gsT0FBTztBQUFBLElBQ1AsUUFBUSxRQUFRO0FBQUEsRUFDbEI7QUFBQSxFQUNBO0FBQUEsSUFDRSxNQUFNLE9BQU87QUFBQSxJQUNiLElBQUksT0FBTztBQUFBLElBQ1gsT0FBTztBQUFBLElBQ1AsUUFBUSxRQUFRO0FBQUEsRUFDbEI7QUFBQSxFQUNBO0FBQUEsSUFDRSxNQUFNLE9BQU87QUFBQSxJQUNiLElBQUksT0FBTztBQUFBLElBQ1gsT0FBTztBQUFBLElBQ1AsUUFBUSxRQUFRO0FBQUEsRUFDbEI7QUFBQSxFQUNBO0FBQUEsSUFDRSxNQUFNLE9BQU87QUFBQSxJQUNiLElBQUksT0FBTztBQUFBLElBQ1gsT0FBTztBQUFBLElBQ1AsUUFBUSxRQUFRO0FBQUEsRUFDbEI7QUFBQSxFQUNBO0FBQUEsSUFDRSxNQUFNLE9BQU87QUFBQSxJQUNiLElBQUksT0FBTztBQUFBLElBQ1gsT0FBTztBQUFBLElBQ1AsUUFBUSxRQUFRO0FBQUEsRUFDbEI7QUFDRjtBQUVPLElBQU0sU0FBUyxhQUFhO0FBQUEsRUFDakMsZUFBZTtBQUFBLElBQ2IsTUFBTTtBQUFBLElBQ04sT0FBTztBQUFBLElBQ1AsaUJBQWlCO0FBQUEsSUFDakIsUUFBUTtBQUFBLE1BQ04sUUFBUTtBQUFBLFFBQ04sT0FBTztBQUFBLFFBQ1AsUUFBUTtBQUFBLFVBQ04sSUFBSSxFQUFFLE1BQU0sUUFBUSxJQUFJLE1BQU0sU0FBUyxvQkFBb0I7QUFBQSxVQUMzRCxZQUFZLEVBQUUsTUFBTSxRQUFRLFNBQVMsY0FBYztBQUFBLFVBQ25ELFlBQVksRUFBRSxNQUFNLFdBQVcsU0FBUyxNQUFNO0FBQUEsVUFDOUMsUUFBUSxFQUFFLE1BQU0sUUFBUSxTQUFTLFlBQVk7QUFBQSxVQUM3QyxXQUFXLEVBQUUsTUFBTSxhQUFhLFNBQVMsdUJBQXVCO0FBQUEsUUFDbEU7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRixDQUFDOzs7QUh4SUQsU0FBUyxrQkFBa0IsT0FBTztBQUM5QixRQUFNLGNBQWM7QUFBQSxJQUNoQixJQUFJO0FBQUEsSUFDSixJQUFJO0FBQUEsSUFDSixJQUFJO0FBQUEsSUFDSixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixHQUFHLE1BQU07QUFBQSxFQUNiLEdBQUcsRUFBRSxZQUFZLFVBQVUsY0FBYyxXQUFXLFNBQVMsZUFBZSxpQkFBaUIsK0JBQStCLGlCQUFpQixzQkFBc0IsbUJBQW1CLElBQUk7QUFDMUwsTUFBSSxDQUFDO0FBQ0QseUJBQXFCLGNBQWMsSUFBSTtBQUMzQyxNQUFJLENBQUM7QUFDRCx5QkFBcUIsWUFBWSxJQUFJO0FBQ3pDLE1BQUksQ0FBQztBQUNELHlCQUFxQixnQkFBZ0IsSUFBSTtBQUM3QyxNQUFJLENBQUM7QUFDRCx5QkFBcUIsYUFBYSxJQUFJO0FBQzFDLE1BQUksQ0FBQztBQUNELHlCQUFxQixXQUFXLElBQUk7QUFDeEMsTUFBSSxDQUFDO0FBQ0QseUJBQXFCLGlCQUFpQixJQUFJO0FBQzlDLE1BQUksQ0FBQztBQUNELHlCQUFxQixtQkFBbUIsSUFBSTtBQUNoRCxNQUFJLENBQUM7QUFDRCx5QkFBcUIsaUNBQWlDLElBQUk7QUFDOUQsTUFBSSxDQUFDO0FBQ0QseUJBQXFCLG1CQUFtQixJQUFJO0FBQ2hELE1BQUksQ0FBQztBQUNELHlCQUFxQix3QkFBd0IsSUFBSTtBQUNyRCxNQUFJLENBQUM7QUFDRCx5QkFBcUIsc0JBQXNCLElBQUk7QUFDbkQsU0FBTyxNQUFNLFdBQVcsRUFBRSxVQUFVLENBQUMsS0FBSyxZQUFZLElBQUksRUFBRSwyQkFBMkIsS0FBSyx5QkFBeUIsTUFBTSxVQUFVLG9DQUFvQyxDQUFDLEdBQUcsTUFBTSxNQUFNLGVBQWUsRUFBRSxPQUFPLFdBQVcsVUFBVSxDQUFDLEtBQUssWUFBWSxJQUFJLEVBQUUsMkJBQTJCLEtBQUsseUJBQXlCLE1BQU0sVUFBVSxVQUFVLENBQUMsR0FBRyxLQUFLLFlBQVksR0FBRyxFQUFFLDJCQUEyQixLQUFLLHlCQUF5QixLQUFLLFVBQVUsbUpBQW1KLENBQUMsR0FBRyxLQUFLLCtCQUErQixFQUFFLGNBQWMsc0JBQXNCLENBQUMsR0FBRyxLQUFLLFlBQVksSUFBSSxFQUFFLDJCQUEyQixLQUFLLHlCQUF5QixNQUFNLFVBQVUsbUJBQW1CLENBQUMsR0FBRyxLQUFLLFlBQVksR0FBRyxFQUFFLDJCQUEyQixLQUFLLHlCQUF5QixLQUFLLFVBQVUsbUlBQW1JLENBQUMsR0FBRyxLQUFLLHNCQUFzQixDQUFDLENBQUMsR0FBRyxLQUFLLFlBQVksSUFBSSxFQUFFLDJCQUEyQixLQUFLLHlCQUF5QixNQUFNLFVBQVUsOEJBQThCLENBQUMsR0FBRyxNQUFNLFlBQVksR0FBRyxFQUFFLDJCQUEyQixLQUFLLHlCQUF5QixLQUFLLFVBQVUsQ0FBQyx5Q0FBeUMsS0FBSyxZQUFZLFFBQVEsRUFBRSxVQUFVLG1CQUFtQixDQUFDLEdBQUcsU0FBUyxLQUFLLFlBQVksUUFBUSxFQUFFLFVBQVUsb0JBQW9CLENBQUMsR0FBRyw2Q0FBNkMsRUFBRSxDQUFDLEdBQUcsS0FBSyxVQUFVLEVBQUUsUUFBUSxRQUFRLFdBQVcsQ0FBQyxHQUFHLE1BQU0sWUFBWSxHQUFHLEVBQUUsMkJBQTJCLEtBQUsseUJBQXlCLEtBQUssVUFBVSxDQUFDLHNDQUFzQyxLQUFLLFlBQVksRUFBRSxRQUFRLFFBQVEsWUFBWSxVQUFVLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLE1BQU0sZUFBZSxFQUFFLE9BQU8scUJBQXFCLFVBQVUsQ0FBQyxLQUFLLFlBQVksSUFBSSxFQUFFLDJCQUEyQixLQUFLLHlCQUF5QixNQUFNLFVBQVUsb0JBQW9CLENBQUMsR0FBRyxNQUFNLFlBQVksR0FBRyxFQUFFLDJCQUEyQixLQUFLLHlCQUF5QixLQUFLLFVBQVUsQ0FBQyw4RUFBOEUsS0FBSyxZQUFZLFFBQVEsRUFBRSxVQUFVLFVBQVUsQ0FBQyxHQUFHLGdHQUFnRyxLQUFLLFlBQVksUUFBUSxFQUFFLFVBQVUsWUFBWSxDQUFDLEdBQUcsK0JBQStCLEVBQUUsQ0FBQyxHQUFHLE1BQU0sWUFBWSxHQUFHLEVBQUUsMkJBQTJCLE1BQU0seUJBQXlCLEtBQUssVUFBVSxDQUFDLFFBQVEsS0FBSyxZQUFZLFFBQVEsRUFBRSxVQUFVLE9BQU8sQ0FBQyxHQUFHLDZFQUE2RSxLQUFLLFlBQVksUUFBUSxFQUFFLFVBQVUsU0FBUyxDQUFDLEdBQUcsNkNBQTZDLEVBQUUsQ0FBQyxHQUFHLEtBQUssb0JBQW9CLEVBQUUsTUFBTSxXQUFXLFVBQVUsS0FBSyxZQUFZLEdBQUcsRUFBRSwyQkFBMkIsTUFBTSx5QkFBeUIsS0FBSyxVQUFVLDZCQUE2QixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sTUFBTSxlQUFlLEVBQUUsT0FBTyx3QkFBd0IsVUFBVSxDQUFDLEtBQUssWUFBWSxJQUFJLEVBQUUsMkJBQTJCLE1BQU0seUJBQXlCLE1BQU0sVUFBVSx1QkFBdUIsQ0FBQyxHQUFHLEtBQUssWUFBWSxHQUFHLEVBQUUsMkJBQTJCLE1BQU0seUJBQXlCLEtBQUssVUFBVSw2SkFBNkosQ0FBQyxHQUFHLEtBQUssVUFBVSxFQUFFLFFBQVEsUUFBUSxrQkFBa0IsQ0FBQyxHQUFHLE1BQU0sWUFBWSxHQUFHLEVBQUUsMkJBQTJCLE1BQU0seUJBQXlCLEtBQUssVUFBVSxDQUFDLFdBQVcsS0FBSyxZQUFZLFFBQVEsRUFBRSxVQUFVLFVBQVUsQ0FBQyxHQUFHLDBJQUEwSSxFQUFFLENBQUMsR0FBRyxNQUFNLFlBQVksR0FBRyxFQUFFLDJCQUEyQixNQUFNLHlCQUF5QixLQUFLLFVBQVUsQ0FBQywrQkFBK0IsS0FBSyxZQUFZLFFBQVEsRUFBRSxVQUFVLGdCQUFnQixDQUFDLEdBQUcsbUVBQW1FLEtBQUssWUFBWSxRQUFRLEVBQUUsVUFBVSxVQUFVLENBQUMsR0FBRywrQ0FBK0MsRUFBRSxDQUFDLEdBQUcsTUFBTSxZQUFZLEdBQUcsRUFBRSwyQkFBMkIsTUFBTSx5QkFBeUIsS0FBSyxVQUFVLENBQUMsMEVBQTBFLEtBQUssWUFBWSxRQUFRLEVBQUUsVUFBVSxJQUFJLENBQUMsR0FBRywyRUFBMkUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxNQUFNLGVBQWUsRUFBRSxPQUFPLHdCQUF3QixVQUFVLENBQUMsS0FBSyxZQUFZLElBQUksRUFBRSwyQkFBMkIsTUFBTSx5QkFBeUIsTUFBTSxVQUFVLHVCQUF1QixDQUFDLEdBQUcsS0FBSyxZQUFZLEdBQUcsRUFBRSwyQkFBMkIsTUFBTSx5QkFBeUIsS0FBSyxVQUFVLHNIQUFzSCxDQUFDLEdBQUcsS0FBSyxpQkFBaUIsRUFBRSxPQUFPLDJCQUEyQixVQUFVLGlCQUFpQixDQUFDLEdBQUcsS0FBSyxZQUFZLEdBQUcsRUFBRSwyQkFBMkIsTUFBTSx5QkFBeUIsS0FBSyxVQUFVLDZFQUE2RSxDQUFDLEdBQUcsTUFBTSxjQUFjLEVBQUUsT0FBTyxpQkFBaUIsUUFBZ0IsUUFBUSxLQUFLLFVBQVUsQ0FBQyxLQUFLLFdBQVcsRUFBRSxJQUFJLGdCQUFnQixPQUFPLG1CQUFtQixVQUFVLEtBQUssU0FBUyxFQUFFLE1BQU0sT0FBTyxjQUFjLElBQUksT0FBTyxjQUFjLE9BQU8sT0FBTyxRQUFRLE9BQU8sdUJBQXVCLFFBQVEsUUFBUSxZQUFZLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUUsSUFBSSxpQkFBaUIsT0FBTyxvQkFBb0IsVUFBVSxLQUFLLFNBQVMsRUFBRSxNQUFNLE9BQU8sUUFBUSxJQUFJLE9BQU8sY0FBYyxPQUFPLE9BQU8sUUFBUSxPQUFPLDBCQUEwQixRQUFRLFFBQVEsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0saUJBQWlCLEVBQUUsU0FBUyxlQUFlLFVBQVUsQ0FBQyxNQUFNLFlBQVksR0FBRyxFQUFFLDJCQUEyQixNQUFNLHlCQUF5QixLQUFLLFVBQVUsQ0FBQyxxQkFBcUIsS0FBSyxZQUFZLFFBQVEsRUFBRSxVQUFVLE1BQU0sQ0FBQyxHQUFHLHdHQUF3RyxFQUFFLENBQUMsR0FBRyxLQUFLLG9CQUFvQixFQUFFLE1BQU0sT0FBTyxVQUFVLHdCQUF3QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxNQUFNLGVBQWUsRUFBRSxPQUFPLFlBQVksVUFBVSxDQUFDLEtBQUssWUFBWSxJQUFJLEVBQUUsMkJBQTJCLE1BQU0seUJBQXlCLE1BQU0sVUFBVSxXQUFXLENBQUMsR0FBRyxNQUFNLFlBQVksR0FBRyxFQUFFLDJCQUEyQixNQUFNLHlCQUF5QixLQUFLLFVBQVUsQ0FBQyxnRUFBZ0UsS0FBSyxZQUFZLFFBQVEsRUFBRSxVQUFVLCtCQUEwQixDQUFDLEdBQUcscURBQXFELEtBQUssWUFBWSxRQUFRLEVBQUUsVUFBVSxzQ0FBaUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ240TTtBQUNlLFNBQVIsV0FBNEIsUUFBUSxDQUFDLEdBQUc7QUFDM0MsUUFBTSxFQUFFLFNBQVMsVUFBVSxJQUFJLE1BQU0sY0FBZSxDQUFDO0FBQ3JELFNBQU8sWUFBWSxLQUFLLFdBQVcsRUFBRSxHQUFHLE9BQU8sVUFBVSxLQUFLLG1CQUFtQixFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLGtCQUFrQixLQUFLO0FBQy9IO0FBQ0EsU0FBUyxxQkFBcUIsSUFBSSxXQUFXO0FBQ3pDLFFBQU0sSUFBSSxNQUFNLGVBQWUsWUFBWSxjQUFjLFlBQVksT0FBTyxLQUFLLG9FQUFvRTtBQUN6SjtBQUVBLE1BQU0seUJBQXlCOzs7QUlyRC9CLFNBQVMsa0NBQWtDO0FBQ3BDLElBQU0sdUJBQXVCLDJCQUEyQjtBQUFBLEVBQzdELE1BQU07QUFBQSxFQUNOLFdBQVc7QUFBQSxFQUNYLFVBQVU7QUFBQSxFQUNWLE9BQU87QUFBQSxFQUNQLFlBQVksQ0FBQztBQUFBLEVBQ2IsUUFBUTtBQUFBLEVBQ1IsV0FBZ0M7QUFBQSxFQUNoQyxXQUFXO0FBQ2IsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
